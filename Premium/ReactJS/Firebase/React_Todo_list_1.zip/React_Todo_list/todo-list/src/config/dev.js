export const FirebaseConfig = {
    apiKey: 'AIzaSyClNg6MeSLMp7IBK_myLYogRNhB90gXePQ',
    authoDomain: 'todo-list-3f74c.firebaseapp.com' ,
    databaseURL: 'https://todo-list-3f74c.firebaseio.com',
    projectId: 'todo-list-3f74c',
    storageBucket: 'todo-list-3f74c.appspot.com',
    messagingSenderId: '1075358711640'
}